<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Observer\Sales;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Sales\Api\ShipmentRepositoryInterface;
use Magento\Sales\Api\Data\ShipmentTrackInterfaceFactory;
use Kyte\Shipping\Helper\Data;
use Kyte\Shipping\Model\WaybillFactory;

class OrderShipmentSaveAfter implements \Magento\Framework\Event\ObserverInterface
{

    const SHIPPING_METHOD = 'kyteshipping_kyteshipping';

    const CARRIER_CODE = 'kyteshipping';

    const CARRIER_TITLE = 'TruxCargo Shipping';

    /**
     * @var ResultFactory
     * */
    protected $resultFactory;

    /**
     * @var RedirectInterface
     * */
    protected $redirect;

    /**
     * @var ManagerInterface
     * */
    protected $messageManager;

    /**
     * @var RedirectFactory
     * */
    protected $resultRedirectFactory;

    /**
     * @var ShipmentRepositoryInterface
     * */
    protected $shipmentRepository;

    /**
     * @var ShipmentTrackInterfaceFactory
     * */
    protected $trackFactory;

    /**
     * @var Data
     * */
    protected $helper;

    /**
     * @var WaybillFactory
     * */
    protected $waybillFactory;

    /**
     * @param ResultFactory $resultFactory
     * @param RedirectInterface $redirect
     * @param ManagerInterface $messageManager
     * @param RedirectFactory $resultRedirectFactory
     * @param ShipmentRepositoryInterface $shipmentRepository
     * @param ShipmentTrackInterfaceFactory $trackFactory
     * @param Data $helper
     * @param WaybillFactory $waybillFactory
     */
    public function __construct(
        ResultFactory $resultFactory,
        RedirectInterface $redirect,
        ManagerInterface $messageManager,
        RedirectFactory $resultRedirectFactory,
        ShipmentRepositoryInterface $shipmentRepository,
        ShipmentTrackInterfaceFactory $trackFactory,
        Data $helper,
        WaybillFactory $waybillFactory
    ) {
        $this->resultFactory = $resultFactory;
        $this->redirect = $redirect;
        $this->messageManager = $messageManager;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->shipmentRepository = $shipmentRepository;
        $this->trackFactory = $trackFactory;
        $this->helper = $helper;
        $this->waybillFactory = $waybillFactory;
    }

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * 
     * @return void
     * 
     * @throws Magento\Framework\Exception\LocalizedException
     */
    public function execute(
        \Magento\Framework\Event\Observer $observer
    ) {
        // shipment object
       $shipment = $observer->getEvent()->getShipment();
       // order object
        $order = $shipment->getOrder();

       if ($order->getShippingMethod() == self::SHIPPING_METHOD) {
            $payload = $this->getBookingDataFormat($shipment);
            $carrierData = $this->helper->bookingCreation($payload);
            try {
                $track = $this->trackFactory->create()->setNumber(
                    $carrierData['waybill']
                )->setCarrierCode(
                    self::CARRIER_CODE
                )->setTitle(
                    self::CARRIER_TITLE
                );
                $shipment->addTrack($track);
                $this->shipmentRepository->save($shipment);
                $data = [
                    'order_id' => $order->getIncrementId(),
                    'shipment_id' => $shipment->getIncrementId(),
                    'waybill_number' => $carrierData['waybill']
                ];
                $this->saveToWayBill($data);
            } catch (NoSuchEntityException $e) {
                $message = "Something went wrong assign track number time";
               throw new \Magento\Framework\Exception\LocalizedException(__($message));
               return;
            }
       }
    }

    /**
     * getBookingDataFormat
     * 
     * @param \Magento\Sales\Model\Order\Shipment $shipment
     * 
     * @return mixed
     * */
    public function getBookingDataFormat($shipment)
    {
        $response = [];
        $objectData = [];

        // set order id
        $objectData['orderNumber'] = $shipment->getOrder()->getIncrementId();
        // order payment method title
        $methodcode = ($shipment->getOrder()->getPayment()->getMethodInstance()->getCode() == 'cashondelivery' || 'checkmo') ? "COD" :"PREPAID";
        $products = $shipment->getItems();
        $basePriceInclTax = 0;
        foreach ($products as $pkey => $product) {
            // set item price
            $basePriceInclTax += floatval($product->getBasePriceInclTax());
            // product object
            $product = [
                "id" => $product->getProductId(),
                "name" => $product->getName(),
                "code" => $product->getSku(),
                "description" => $product->getDescription(),
                "minimumChargeableWeight" => 1,
                "maximumChargeableWeight" => 100,
                "length" => 1,
                "breadth" => 1,
                "height" => 1,
            ];
            // products object
            $objectData['shipment']['product'][] = $product;
        }
        // ========= set shipment data ========
        // set shippment id
        $objectData['shipment']['shipmentId'] = $shipment->getIncrementId();
        // set order create date
        $objectData['shipment']['bookingDate'] = str_replace(" ", "T", $shipment->getOrder()->getCreatedAt()).'.000Z';
        // set pieces 
        $objectData['shipment']['pieces'] = $shipment->getTotalQty();
        // set length 
        $objectData['shipment']['length'] = 1;
        // set breadth 
        $objectData['shipment']['breadth'] = 1;
        // set height 
        $objectData['shipment']['height'] = 1;
        // set actualWeight 
        $objectData['shipment']['actualWeight'] = $shipment->getTotalWeight() ?? 1;
        // set shipmentValue 
        $objectData['shipment']['shipmentValue'] = $basePriceInclTax;
        // set paymentType 
        $objectData['shipment']['paymentType'] = $methodcode;
        // set codAmount 
        $objectData['shipment']['codAmount'] = $basePriceInclTax;
        // set booking type
        $objectData['shipment']['bookingType'] = 'CREDIT';

        // ========= set consignee Data ==========
        // get shipping address from shipment order
        $shippingAddress = $shipment->getOrder()->getShippingAddress();
        $streetAddress = $shippingAddress->getStreet();
        $consignee = [
            'name' => $shippingAddress->getFirstName().' '.$shippingAddress->getLastName(),
            'contactNo' => $shippingAddress->getTelephone(),
            'address' => [
                'address1' => $streetAddress[0] ?? "",
                'address2' => $streetAddress[1] ?? "",
                'zipcode' => $shippingAddress->getPostcode(),
                'cityName' => $shippingAddress->getCity(),
                'region' => $shippingAddress->getRegionId(),
                'country' => $shippingAddress->getCountryId()
            ]
        ];

        // set booking type
        $objectData['consignee'] = $consignee;
        $response[] = $objectData;
        return $response;
    }


    /**
     * saveToWayBill
     * 
     * @param mixed
     * 
     * @return void
     * */
    public function saveToWayBill($data = [])
    {
        $model = $this->waybillFactory->create();
        $model->addData($data);
        $model->save();
    }
}

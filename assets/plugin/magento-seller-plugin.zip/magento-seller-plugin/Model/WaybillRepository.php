<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Model;

use Kyte\Shipping\Api\Data\WaybillInterface;
use Kyte\Shipping\Api\Data\WaybillInterfaceFactory;
use Kyte\Shipping\Api\Data\WaybillSearchResultsInterfaceFactory;
use Kyte\Shipping\Api\WaybillRepositoryInterface;
use Kyte\Shipping\Model\ResourceModel\Waybill as ResourceWaybill;
use Kyte\Shipping\Model\ResourceModel\Waybill\CollectionFactory as WaybillCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;

class WaybillRepository implements WaybillRepositoryInterface
{

    /**
     * @var ResourceWaybill
     */
    protected $resource;

    /**
     * @var WaybillInterfaceFactory
     */
    protected $waybillFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var Waybill
     */
    protected $searchResultsFactory;

    /**
     * @var WaybillCollectionFactory
     */
    protected $waybillCollectionFactory;


    /**
     * @param ResourceWaybill $resource
     * @param WaybillInterfaceFactory $waybillFactory
     * @param WaybillCollectionFactory $waybillCollectionFactory
     * @param WaybillSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceWaybill $resource,
        WaybillInterfaceFactory $waybillFactory,
        WaybillCollectionFactory $waybillCollectionFactory,
        WaybillSearchResultsInterfaceFactory $searchResultsFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->waybillFactory = $waybillFactory;
        $this->waybillCollectionFactory = $waybillCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @inheritDoc
     */
    public function save(WaybillInterface $waybill)
    {
        try {
            $this->resource->save($waybill);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the waybill: %1',
                $exception->getMessage()
            ));
        }
        return $waybill;
    }

    /**
     * @inheritDoc
     */
    public function get($waybillId)
    {
        $waybill = $this->waybillFactory->create();
        $this->resource->load($waybill, $waybillId);
        if (!$waybill->getId()) {
            throw new NoSuchEntityException(__('waybill with id "%1" does not exist.', $waybillId));
        }
        return $waybill;
    }

    /**
     * @inheritDoc
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->waybillCollectionFactory->create();
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model;
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @inheritDoc
     */
    public function delete(WaybillInterface $waybill)
    {
        try {
            $waybillModel = $this->waybillFactory->create();
            $this->resource->load($waybillModel, $waybill->getWaybillId());
            $this->resource->delete($waybillModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the waybill: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * @inheritDoc
     */
    public function deleteById($waybillId)
    {
        return $this->delete($this->get($waybillId));
    }
}


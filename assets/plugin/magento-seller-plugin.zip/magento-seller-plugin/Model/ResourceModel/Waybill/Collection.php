<?php
/**
 * @package Kyte_Shipping
 */


declare(strict_types=1);

namespace Kyte\Shipping\Model\ResourceModel\Waybill;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{

    /**
     * @inheritDoc
     */
    protected $_idFieldName = 'waybill_id';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init(
            \Kyte\Shipping\Model\Waybill::class,
            \Kyte\Shipping\Model\ResourceModel\Waybill::class
        );
    }

}


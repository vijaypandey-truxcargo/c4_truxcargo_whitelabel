<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Waybill extends AbstractDb
{

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('kyte_shipping_waybill', 'waybill_id');
    }
}


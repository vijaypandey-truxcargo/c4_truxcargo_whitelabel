<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Model\Carrier;

use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Rate\Result;
use Kyte\Shipping\Helper\Data;

class Kyteshipping extends \Magento\Shipping\Model\Carrier\AbstractCarrier implements
    \Magento\Shipping\Model\Carrier\CarrierInterface
{

    protected $_code = 'kyteshipping';

    protected $_isFixed = true;

    /**
     * @var \Magento\Shipping\Model\Rate\ResultFactory
     */
    protected $_rateResultFactory;

    /**
     * @var \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory
     */
    protected $_rateMethodFactory;

    /**
     * @var \Magento\Shipping\Model\Tracking\Result\StatusFactory
     */
    protected $_trackStatusFactory;

    /**
     * @var Data
     */
    private $_helper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param \Magento\Shipping\Model\Tracking\Result\StatusFactory $trackStatusFactory
     * @param Data $helper
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,
        \Magento\Shipping\Model\Tracking\Result\StatusFactory $trackStatusFactory,
        Data $helper,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->_helper = $helper;
        $this->_trackStatusFactory = $trackStatusFactory;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    /**
     * {@inheritdoc}
     */
    public function collectRates(RateRequest $request)
    {
        if (!$this->getConfigFlag('active')) {
            return false;
        }
        $zipcode = $request->getDestPostcode();

        // check service avilable on this destination
        // if service not available method is hide from frontend
        if (!$this->_helper->isAvailableService($zipcode)) {
            return false;
        }

        $shippingPrice = $this->getConfigData('price');

        $result = $this->_rateResultFactory->create();

        if ($shippingPrice !== false) {
            $method = $this->_rateMethodFactory->create();

            $method->setCarrier($this->_code);
            $method->setCarrierTitle($this->getConfigData('title'));

            $method->setMethod($this->_code);
            $method->setMethodTitle($this->getConfigData('name'));

            if ($request->getFreeShipping() === true) {
                $shippingPrice = '0.00';
            }

            $method->setPrice($shippingPrice);
            $method->setCost($shippingPrice);

            $result->append($method);
        }

        return $result;
    }

    /**
     * getAllowedMethods
     *
     * @return array
     */
    public function getAllowedMethods()
    {
        return [$this->_code => $this->getConfigData('name')];
    }

    /**
     * isTrackingAvailable
     * 
     * @return bool
     * 
     */
    public function isTrackingAvailable()
    {
        return true;
    }

        /**
     * Get tracking
     *
     * @param string|string[] $trackings
     * @return Result|null
     */
    public function getTrackingInfo($tracking)
    {
        $result = $this->_trackStatusFactory->create();

        $payload = ['awb' => $tracking];
        $data = $this->_helper->trackShipment($payload);
        $shipments = $data['data']['ShipmentData'] ?? [];
        $result->setCarrier($this->_code);
        $result->setCarrierTitle("TruxCargo Shipping");
        $result->setTracking($tracking);
        $result->setPopup(1);
        $result->setTrackSummary($this->_getSummary($shipments));
        $result->addData($this->_processTrackingDetails($shipments));
        return $result;
    }

    /**
     * Get Summary Title
     * 
     * @param array $shipments
     * 
     * @return string
     * */
    private function _getSummary($shipments = [])
    {
        $summary = null;
        foreach ($shipments as $key => $shipment) {
            $summary = $shipment['Shipment']['Status']['Instructions'] ?? null;
        }
        return $summary;
    }

    /**
     * Parse track details response
     *
     * @param array $shipments
     * 
     * @return array
     */
    private function _processTrackingDetails($shipments = [])
    {
        $result = [
            'shippeddate' => null,
            'deliverydate' => null,
            'deliverytime' => null,
            'deliverylocation' => null,
            'weight' => null,
            'progressdetail' => [],
        ];
        $result['shippeddate'] = date('Y-m-d');
        $result['signedby'] = null;
        $result['status'] = null;
        $result['deliverydate'] = date('Y-m-d');
        $result['deliverytime'] = date('H:i:s');
        $result['deliverylocation'] = 'jaipur';
        $result['weight'] = '10kg';
        
        foreach ($shipments as $shipment) {
            $trackDetail                     = [];
            $trackDetail['deliverylocation'] = $shipment['Shipment']['Status']['StatusLocation'] ?? '';
            $trackDetail['activity']         = $shipment['Shipment']['Status']['Instructions'] ?? '';
            $deliverydate                    = $shipment['Shipment']['Status']['StatusDateTime'] ?? '';
            $trackDetail['deliverydate']     = date('Y-m-d',strtotime($deliverydate));
            $deliverytime                    = $shipment['Shipment']['Status']['StatusDateTime'] ?? '';
            $trackDetail['deliverytime']     = date('H:i:s',strtotime($deliverytime));
            $result['progressdetail'][]      = $trackDetail;
        }
        return $result;
    }


}
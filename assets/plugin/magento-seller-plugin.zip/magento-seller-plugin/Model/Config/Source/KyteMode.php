<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Model\Config\Source;

class KyteMode implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * Option array
     * 
     * @return mixed
     * */
    public function toOptionArray()
    {
        return [['value' => 'live', 'label' => __('Live')],['value' => 'sandbox', 'label' => __('Sandbox')]];
    }

    /**
     * Option array
     * 
     * @return mixed
     * */
    public function toArray()
    {
        return ['live' => __('Live'),'sandbox' => __('Sandbox')];
    }
}


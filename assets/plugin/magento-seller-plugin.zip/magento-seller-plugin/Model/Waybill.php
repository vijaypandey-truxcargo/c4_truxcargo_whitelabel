<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Model;

use Kyte\Shipping\Api\Data\WaybillInterface;
use Magento\Framework\Model\AbstractModel;

class Waybill extends AbstractModel implements WaybillInterface
{

    /**
     * @inheritDoc
     */
    public function _construct()
    {
        $this->_init(\Kyte\Shipping\Model\ResourceModel\Waybill::class);
    }

    /**
     * @inheritDoc
     */
    public function getWaybillId()
    {
        return $this->getData(self::WAYBILL_ID);
    }

    /**
     * @inheritDoc
     */
    public function setWaybillId($waybillId)
    {
        return $this->setData(self::WAYBILL_ID, $waybillId);
    }

    /**
     * @inheritDoc
     */
    public function getOrderId()
    {
        return $this->getData(self::ORDER_ID);
    }

    /**
     * @inheritDoc
     */
    public function setOrderId($orderId)
    {
        return $this->setData(self::ORDER_ID, $orderId);
    }


    /**
     * @inheritDoc
     */
    public function getShipmentId()
    {
        return $this->getData(self::SHIPMENT_ID);
    }

    /**
     * @inheritDoc
     */
    public function setShipmentId($shipmentId)
    {
        return $this->setData(self::SHIPMENT_ID, $shipmentId);
    }


    /**
     * @inheritDoc
     */
    public function getWaybillNumber()
    {
        return $this->getData(self::WAYBILL_NUMBER);
    }

    /**
     * @inheritDoc
     */
    public function setWaybillNumber($waybillNumber)
    {
        return $this->setData(self::WAYBILL_NUMBER, $waybillNumber);
    }
}


# Magento 2 TruxCargo Shipping

Overview
==================

TruxCargo Shipping extension for Magento helps to seamlessly integrate TruxCargo Shipping within your Magento store.
The extension uses your own TruxCargo Shipping Account and provides a complete TruxCargo Shipping solution for your Magento store.
It helps to automatically display TruxCargo Shipping rates at the Magento checkout page,
generate TruxCargo Shipping labels directly from the Magento orders page, and track your TruxCargo Shipping in real-time.

🛠️ Installation
-------------

**Using Zip**

* Download the Zip File
* Extract & upload the files to `/path/to/magento2/app/code/Kyte/Shipping/`

After installation by either means, enable the extension by running following commands (again from root of Magento2 installation):

`php bin/magento module:enable Kyte_Shipping --clear-static-content`
------------
`php bin/magento setup:upgrade`
------------
`php bin/magento setup:di:compile`
------------
`php bin/magento cache:flush`
------------
🚀 Screenshots
-----------

![alt text](https://i.imgur.com/a7rh03Y.png)
#Setup backend setting
<br/>




![alt text](https://i.imgur.com/ocD33PQ.png)


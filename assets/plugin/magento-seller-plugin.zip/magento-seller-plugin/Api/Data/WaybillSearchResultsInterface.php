<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Api\Data;

interface WaybillSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get waybill list.
     * @return \Kyte\Shipping\Api\Data\WaybillInterface[]
     */
    public function getItems();

    /**
     * Set order_id list.
     * @param \Kyte\Shipping\Api\Data\WaybillInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}


<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Api\Data;

interface WaybillInterface
{

    const WAYBILL_ID = 'waybill_id';
    const ORDER_ID = 'order_id';
    const SHIPMENT_ID = 'shipment_id';
    const WAYBILL_NUMBER = 'waybill_number';

    /**
     * Get waybill_id
     * @return string|null
     */
    public function getWaybillId();

    /**
     * Set waybill_id
     * @param string $waybillId
     * @return \Kyte\Shipping\Waybill\Api\Data\WaybillInterface
     */
    public function setWaybillId($waybillId);

    /**
     * Get order_id
     * @return string|null
     */
    public function getOrderId();

    /**
     * Set order_id
     * @param string $orderId
     * @return \Kyte\Shipping\Waybill\Api\Data\WaybillInterface
     */
    public function setOrderId($orderId);


    /**
     * Get shipment_id
     * @return string|null
     */
    public function getShipmentId();

    /**
     * Set shipment_id
     * @param string $shipmentId
     * @return \Kyte\Shipping\Waybill\Api\Data\WaybillInterface
     */
    public function setShipmentId($shipmentId);

    /**
     * Get waybill_number
     * @return string|null
     */
    public function getWaybillNumber();

    /**
     * Set waybill_number
     * @param string $waybillNumber
     * @return \Kyte\Shipping\Waybill\Api\Data\WaybillInterface
     */
    public function setWaybillNumber($waybillNumber);
}


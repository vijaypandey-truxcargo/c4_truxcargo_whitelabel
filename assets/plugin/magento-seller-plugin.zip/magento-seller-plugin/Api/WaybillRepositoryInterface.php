<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface WaybillRepositoryInterface
{

    /**
     * Save waybill
     * @param \Kyte\Shipping\Api\Data\WaybillInterface $waybill
     * @return \Kyte\Shipping\Api\Data\WaybillInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \Kyte\Shipping\Api\Data\WaybillInterface $waybill
    );

    /**
     * Retrieve waybill
     * @param string $waybillId
     * @return \Kyte\Shipping\Api\Data\WaybillInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($waybillId);

    /**
     * Retrieve waybill matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Kyte\Shipping\Api\Data\WaybillSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete waybill
     * @param \Kyte\Shipping\Api\Data\WaybillInterface $waybill
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \Kyte\Shipping\Api\Data\WaybillInterface $waybill
    );

    /**
     * Delete waybill by ID
     * @param string $waybillId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($waybillId);
}


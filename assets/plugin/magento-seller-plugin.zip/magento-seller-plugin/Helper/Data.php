<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\HTTP\Client\Curl;

class Data extends AbstractHelper
{
    // Live Mode
	const SERVICE_LIVE_ABILITY_END_POINT = 'https://kyte-aggregator/api/v1/orderb2c/serviceability/';
    const BOOKING_LIVE_CREATION_END_POINT = 'https://kyte-aggregator/api/v1/orderb2c/booking';
    const SHIPPING_LIVE_TRACKING_END_POINT = 'https://api-stage.kyte.app/kyte-aggregator-service/api/v1/tracking/';
    const SHIPPING_LIVE_SHIPPING_LABEL_END_POINT = 'https://api-stage.kyte.app/kyte-aggregator-service/api/v1/shipping-label/?waybill=';

    // Sandbox Mode
    const SERVICE_SANDBOX_ABILITY_END_POINT = 'https://api-stage.kyte.app/kyte-aggregator-service/api/v1/orderb2c/serviceablity/';
    const BOOKING_SANDBOX_CREATION_END_POINT = 'https://api-stage.kyte.app/kyte-aggregator-service/api/v1/booking/';
    const SHIPPING_SANDBOX_TRACKING_END_POINT = 'https://api-stage.kyte.app/kyte-aggregator-service/api/v1/tracking/';
    const SHIPPING_SANDBOX_SHIPPING_LABEL_END_POINT = 'https://api-stage.kyte.app/kyte-aggregator-service/api/v1/shipping-label/?waybill=';

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param Curl $curl
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        Curl $curl
    ) {
    	$this->curlClient = $curl;
        parent::__construct($context);
    }

    /**
     * @return bool
     */
    public function isEnabled()
    {
        return true;
    }

    /**
     * Check Available Service on the location
     * 
     * @param string|int $zipcode
     * 
     * @return bool
     * */
    public function isAvailableService($zipcode)
    {
        $endpoint = self::SERVICE_SANDBOX_ABILITY_END_POINT.$zipcode;
        if ($this->isLiveMode()) {
            $endpoint = self::SERVICE_LIVE_ABILITY_END_POINT.$zipcode;
        }
    	$headers = $this->getAuthHeader();
    	try {
            $this->getCurlClient()->setHeaders($headers);
    		$this->getCurlClient()->get($endpoint);
    		$response = json_decode($this->getCurlClient()->getBody(), true);
            $isAvailable = $response['data']['servicable'] ?? 0;
            if ($isAvailable) {
                return true;
            }
    		return false;
    	} catch (\Exception $e) {
    		return false;
    	}
    }

    /**
     * bookingCreation
     * 
     * @param mexed $payload
     * 
     * @return mixed
     */
    public function bookingCreation($payload = [])
    {
        $endpoint = self::BOOKING_LIVE_CREATION_END_POINT;
        if (!$this->isLiveMode()) {
          $endpoint = self::BOOKING_SANDBOX_CREATION_END_POINT;
        }
        $headers = $this->getAuthHeader();
        try {
            $jsonData = json_encode($payload);
            $this->getCurlClient()->setHeaders($headers);
            $this->getCurlClient()->post($endpoint, $jsonData);
            $response = json_decode($this->getCurlClient()->getBody(), true);
            $status = $response[0]['success'] ?? 0;
            if ($status) {
                $waybill = $response[0]['awb'] ?? null;
                return ["waybill" =>$waybill];
            }
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Something went wrong. while saving AWB!'));
        }
    }

    /**
     * @return Curl
     */
    public function getCurlClient()
    {
        return $this->curlClient;
    }

    /**
     * Request Auth Header
     * 
     * @return mixed
     * */
    public function getAuthHeader()
    {
        $apiKey = $this->scopeConfig->getValue('carriers/kyteshipping/api_key', ScopeInterface::SCOPE_STORE);
        $sellerId = $this->scopeConfig->getValue('carriers/kyteshipping/seller_id', ScopeInterface::SCOPE_STORE);
        $tenantId = $this->scopeConfig->getValue('carriers/kyteshipping/tenant_id', ScopeInterface::SCOPE_STORE);
        return [
            'cache-control' => 'no-cache',
            'channel' => 'Magento',
            'Content-Type' => 'application/json',
            'api_token' => $apiKey,
            'lsp' => $tenantId,
            'seller_id' => $sellerId
          ];
    }

    /**
     * shippingLabelCreate
     * 
     * @param array $payload
     * 
     * @return string
     * 
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function shippingLabelCreate($payload = [])
    {
        $endpoint = self::SHIPPING_LABEL_END_POINT;
        $headers = $this->getAuthHeader();
        try {
            $this->getCurlClient()->post($endpoint, json_encode($payload));
            $this->getCurlClient()->setHeaders($headers);
            $response = json_decode($this->getCurlClient()->getBody(), true);
            return "";
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Something went wrong. while Creating shipping Label!'));
        }
    }

    /**
     * shippingLabelDownload
     * 
     * @param string $waybill
     * 
     * @return string
     * 
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function shippingLabelDownload($waybill)
    {
        $endpoint = self::SHIPPING_LIVE_SHIPPING_LABEL_END_POINT.$waybill;
        if (!$this->isLiveMode()) {
           $endpoint = self::SHIPPING_SANDBOX_SHIPPING_LABEL_END_POINT.$waybill;
        }
        $headers = $this->getAuthHeader();
        try {
            $headers['Content-Type'] = "application/pdf";
            $this->getCurlClient()->setHeaders($headers);
            $this->getCurlClient()->get($endpoint);
            //$response = json_decode($this->getCurlClient()->getBody(), true);
            return $this->getCurlClient()->getBody();
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Something went wrong. while print Shipment!'));
        }
    }

    /**
     * trackShipment
     * 
     * @param array $payload
     * 
     * @return array
     * 
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function trackShipment($payload = [])
    {
        $endpoint = self::SHIPPING_LIVE_TRACKING_END_POINT;
        if (!$this->isLiveMode()) {
          $endpoint = self::SHIPPING_SANDBOX_TRACKING_END_POINT;
        }
        $headers = $this->getAuthHeader();
        try {
            $jsonData = json_encode($payload);
            $this->getCurlClient()->setHeaders($headers);
            $this->getCurlClient()->post($endpoint, $jsonData);
            $response = json_decode($this->getCurlClient()->getBody(), true);
            return $response;
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Something went wrong. while saving AWB!'));
        }
    }

    /**
     * Shipping Method Mode
     * 
     * @return bool
     * */
    public function isLiveMode()
    {
        $kyteMode = $this->scopeConfig->getValue('carriers/kyteshipping/kyte_mode', ScopeInterface::SCOPE_STORE);
        if ($kyteMode =='live') {
            return true;
        }
        return false;
    }
}

<?php
/**
 * @package Kyte_Shipping
 */
use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Kyte_Shipping', __DIR__);


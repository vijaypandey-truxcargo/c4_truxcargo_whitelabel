<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Controller\Adminhtml\Shipment;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Controller\Result\JsonFactory;
use Kyte\Shipping\Model\ResourceModel\Waybill\CollectionFactory;
use Kyte\Shipping\Helper\Data;

class Pickup extends Action
{

    /**
     * @var Filter
     */
    private $_filter;

    /**
     * @var CollectionFactory
     */
    private $_collectionFactory;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     * @param Data $helper
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        Data $helper
    ) {
        $this->_filter = $filter;
        $this->_collectionFactory = $collectionFactory;
        $this->helper = $helper;
        parent::__construct($context);
    }

    /**
     * Execute action.
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     *
     * @throws \Magento\Framework\Exception\LocalizedException|\Exception
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        try {
            $collection = $this->_filter->getCollection($this->_collectionFactory->create());

            $done = 0;
            foreach ($collection as $item) {
                $payload = ["waybill" => $item->getWaybillNumber()];
                $this->helper->shippingLabelCreate($payload);
                $item->setStatus(1);
                $item->save();
                ++$done;
            }

            if ($done) {
                $this->messageManager->addSuccess(__('A total of %1 record(s) were modified.', $done));
            }
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }

        return $resultRedirect->setUrl($this->_redirect->getRefererUrl());
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }
}

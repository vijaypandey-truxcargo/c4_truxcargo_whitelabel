<?php
/**
 * @package Kyte_Shipping
 */

declare(strict_types=1);

namespace Kyte\Shipping\Controller\Adminhtml\Shipment;
use Kyte\Shipping\Helper\Data as KyteHelper;
use Magento\Framework\App\Filesystem\DirectoryList;

class Label extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry
     */
	protected $_coreRegistry;

	/**
	 * @var KyteHelper
	 * */
	protected $kyteHelper;

	/**
	 * @var \Magento\Framework\Controller\Result\RawFactory
	 * */
	protected $resultRawFactory;

	/**
	 * @var \Magento\Framework\App\Response\Http\FileFactory
	 * */
	protected $fileFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Magento\Framework\Controller\Result\RawFactory $resultRawFactory,
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
     * @param KyteHelper $kyteHelper
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\Controller\Result\RawFactory $resultRawFactory,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
        KyteHelper $kyteHelper
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->kyteHelper = $kyteHelper;
        $this->resultRawFactory = $resultRawFactory;
        $this->fileFactory = $fileFactory;
        parent::__construct($context);
    }

    /**
     * Label action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        // check if we know what should be deleted
        $id = $this->getRequest()->getParam('waybill_id');
        if ($id) {
            try {
                $model = $this->_objectManager->create(\Kyte\Shipping\Model\Waybill::class);
                $model->load($id);
                $fileContant = $this->kyteHelper->shippingLabelDownload($model->getWaybillNumber());

                $fileName = 'waybill-'.$model->getWaybillNumber().'.pdf';
		        $this->fileFactory->create($fileName, $fileContant,DirectoryList::TMP, 'application/pdf');
		        return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
                // display error message
                $this->messageManager->addErrorMessage($e->getMessage());
                // go back to edit form
                return $resultRedirect->setPath('*/*/edit', ['waybill_id' => $id]);
            }
        }
        // display error message
        $this->messageManager->addErrorMessage(__('We can\'t find a Waybill to delete.'));
        // go to grid
        return $resultRedirect->setPath('*/*/');
    }
}


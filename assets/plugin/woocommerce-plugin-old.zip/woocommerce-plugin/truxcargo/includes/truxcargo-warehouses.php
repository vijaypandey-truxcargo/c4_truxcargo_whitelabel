<?php
/**
 * The file that defines the Warehouses class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 * @author     Trux Cargo <truxcargo@gmail.com>
 */


if(!class_exists('WP_List_Table')){
	require_once(ABSPATH.'wp-admin/includes/class-wp-list-table.php' );
}

class Warehouses_List_Table extends \WP_List_Table {

	/**
	 * Const to declare number of posts to show per page in the table.
	 */
	const POSTS_PER_PAGE = 10;


	/**
	 * Warehouses_List_Table constructor.
	 */
	public function __construct() {

		parent::__construct(
			array(
				'singular' => 'Warehouse',
				'plural'   => 'Warehouses',
				'ajax'     => false,
			)
		);
	}

	/**
	 * This function get number of warehouse per page in admin grid
	 *
	 * @since     1.0.0
	 * @return    int
	 * @access    private
	 */
	private function get_per_page_warehouses()
	{
		// get the current user ID
		$user = get_current_user_id();
		// get the current admin screen
		$screen = get_current_screen();
		// retrieve the "per_page" option
		$screen_option = $screen->get_option('per_page', 'option');
		// retrieve the value of the option stored for the current user
		$per_page = get_user_meta($user, $screen_option, true);
		if ( empty ( $per_page) || $per_page < 1 ) {
			// get the default value if none is set
			$per_page = $screen->get_option( 'per_page', 'default' );
		}
		return $per_page;
	}

	/**
	 * This function provide all page available accourding to current collection of warehouse data(entries)
	 *
	 * @since     1.0.0
	 * @return    int
	 * @access    private
	 */
	private function get_total_warehouse_page()
	{
		// WP Globals
        global $table_prefix, $wpdb;
        // Warehouse Table
        $warehouse_table = $table_prefix . 'truxcargo_warehouses';
        $searchKey = $_GET['s'] ?? null;
        if ($searchKey && !empty($searchKey)) {
			$total_warehouse = $wpdb->get_var('SELECT COUNT(*) FROM '.$warehouse_table.' WHERE `warehouse` LIKE "%'.$searchKey.'%" or `name` LIKE "%'.$searchKey.'%" or `city` LIKE "%'.$searchKey.'%" or `state` LIKE "%'.$searchKey.'%" or `address` LIKE "%'.$searchKey.'%" or `pincode` LIKE "%'.$searchKey.'%" or `phone` LIKE "%'.$searchKey.'%"');
        } else {
			$total_warehouse = $wpdb->get_var('SELECT COUNT(*) FROM '.$warehouse_table);
        }
		$per_page = $this->get_per_page_warehouses();
		if ($total_warehouse > $per_page) {
			$number_of_pages = $total_warehouse / $per_page;
			return ceil($number_of_pages);
		}
		return 1;
	}

	/**
	 * This function provide collection of warehouse data(entries)
	 *
	 * @since     1.0.0
	 * @return    array
	 */
	protected function get_warehouse_object() {
		// WP Globals
        global $table_prefix, $wpdb;

        $per_page = $this->get_per_page_warehouses();
        
        $paged = filter_input( INPUT_GET, 'paged', FILTER_VALIDATE_INT );

        // ORDER BY
        $orderby = sanitize_sql_orderby( filter_input( INPUT_GET, 'orderby' ) );
        // Order
		$order   = esc_sql( filter_input( INPUT_GET, 'order' ) );
		// search keyword
		$searchKey = esc_sql( filter_input( INPUT_GET, 's' ) );
		if ( empty( $orderby ) || 'view' == $orderby ) {
			$orderby = 'id';
		}

		if ( empty( $order ) || 'view' == $order ) {
			$order = 'DESC';
		}
		$offset = ((int)$paged - 1) * (int)$per_page;
		if ($paged == 0 || $paged == 1) {
			$offset = 0;
		}
        // Waybill Table
        $waybillTable = $table_prefix . 'truxcargo_warehouses';
        if ($searchKey && !empty($searchKey)) {
			return $wpdb->get_results("SELECT * FROM ".$waybillTable.' WHERE `warehouse` LIKE "%'.$searchKey.'%" or `name` LIKE "%'.$searchKey.'%" or `state` LIKE "%'.$searchKey.'%" or `address` LIKE "%'.$searchKey.'%" or `pincode` LIKE "%'.$searchKey.'%" or `phone` LIKE "%'.$searchKey.'%" or `city` LIKE "%'.$searchKey.'%"'.' ORDER BY '.$orderby.' '.$order.' '.' LIMIT '.$per_page.'  OFFSET '.$offset);
        }
		return $wpdb->get_results("SELECT * FROM ".$waybillTable.' ORDER BY '.$orderby.' '.$order.' '.' LIMIT '.$per_page.'  OFFSET '.$offset);
	}

	/**
	 * Display text for when there are no items.
	 */
	public function no_items() {
		esc_html_e( 'No Warehouse found.', 'truxcargo' );
	}

	/**
	 * The Default columns
	 *
	 * @param  array  $item        The Item being displayed.
	 * @param  string $column_name The column we're currently in.
	 * @return string              The Content to display
	 */
	public function column_default( $item, $column_name ) {
		 $item = (array) $item;
		return $item[$column_name];
	}

	/**
	 * Get list columns.
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'warehouse'  => __( 'Warehouse', 'truxcargo' ),
			'name'  => __( 'Name', 'truxcargo' ),
			'phone'  => __( 'Phone', 'truxcargo' ),
			'address'  => __( 'Address', 'truxcargo' ),
			'pincode'  => __( 'Pincode', 'truxcargo' ),
			'city'  => __( 'City', 'truxcargo' ),
			'state'  => __( 'State', 'truxcargo' ),
		);
	}


	/**
	 * Prepare the data for the WP List Table
	 *
	 * @return void
	 */
	public function prepare_items() {
		$columns               = $this->get_columns();
		$sortable              = $this->get_sortable_columns();
		$hidden                = array();
		$primary               = 'title';
		$this->_column_headers = array( $columns, $hidden, $sortable, $primary );
		$data                  = array();


		$get_warehouse_obj = $this->get_warehouse_object();



		$this->items = $get_warehouse_obj;

		$this->set_pagination_args(
			array(
				'total_items' => count($get_warehouse_obj),
				'per_page'    => $this->get_per_page_warehouses(),
				'total_pages'    => $this->get_total_warehouse_page(),
			)
		);
	}

	/**
	 * Get bulk actions.
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		return array();
	}


	/**
	 * Generates the table navigation above or below the table
	 *
	 * @param string $which Position of the navigation, either top or bottom.
	 *
	 * @return void
	 */
	protected function display_tablenav( $which ) {
		?>
	<div class="tablenav <?php echo esc_attr( $which ); ?>">

		<?php if ( $this->has_items() ) : ?>
		<div class="alignleft actions bulkactions">
			<?php $this->bulk_actions( $which ); ?>
		</div>
			<?php
		endif;
		$this->pagination( $which );
		?>

		<br class="clear" />
	</div>
		<?php
	}


	/**
	 * Include the columns which can be sortable.
	 *
	 * @return Array $sortable_columns Return array of sortable columns.
	 */
	public function get_sortable_columns() {

		return array(
			'warehouse'  => array( 'warehouse', false ),
			'name'   => array( 'name', false ),
			'phone'   => array( 'phone', false ),
			'address'   => array( 'address', false ),
			'pincode'   => array( 'pincode', false ),
			'city'   => array( 'city', false ),
			'state'   => array( 'state', false ),
		);
	}
}

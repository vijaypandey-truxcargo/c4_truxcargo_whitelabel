<?php

/**
 * The includes-facing functionality of the plugin.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 */

/**
 * The includes-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the includes-facing stylesheet and JavaScript.
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 * @author     Trux Cargo <truxcargo@gmail.com>
 */
class Truxcargo_Service {

    const SERVICE_LIVE_ABILITY_END_POINT = 'https://b2b.truxcargo.com/api/orderb2c/serviceability/';
    const BOOKING_LIVE_CREATION_END_POINT = 'https://b2b.truxcargo.com/api/orderb2c/creation';
    const SHIPPING_LIVE_TRACKING_END_POINT = 'https://b2b.truxcargo.com/api/orderb2c/tracking';
    const SHIPPING_LIVE_SHIPPING_LABEL_END_POINT = 'https://b2b.truxcargo.com/api/orderb2c/label';
    const DOWNLOAD_WAREHOUSE_LIVE_END_POINT = 'https://b2b.truxcargo.com/api/warehouse/point';
    const SHIPPING_CHARGE_LIVE_END_POINT = 'https://b2b.truxcargo.com/api/orderb2c/shippingcharge';

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->settings = get_option( $this->get_option_key(), null );

	}

	/**
	 * Return the name of the option in the WP DB.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public function get_option_key() {
		return 'woocommerce_' . $this->plugin_name . '_settings';
	}

	/**
     * Check Available Service on the location
     * 
     * @param string|int $zipcode
     * 
     * @return bool
     * */
    public function is_available_service($zipcode)
    {
        global $woocommerce;

        $endpoint = self::SERVICE_LIVE_ABILITY_END_POINT.$zipcode;
        
        try {
	        $args = array(
			    'headers' => [
                            'cache-control' => 'no-cache',
                            'channel' => 'Woocommerce',
                            'Content-Type' => 'application/json'
                        ]
			);
	        $response = wp_remote_get($endpoint, $args);
		  	$response_code = wp_remote_retrieve_response_code( $response );
		  	$response_body = wp_remote_retrieve_body( $response );
	    	$data = json_decode($response_body, true);
	    	$isAvailable = $data['status'] ?? 0;
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"response" =>$data,'response_code' =>$response_code,'response_code' =>$response_code]);
            if ($isAvailable) {
                return true;
            }
    		return false;
	    } catch (Exception $e) {
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"Exception" =>$e->getMessage()]);
    		return false;
    	}
    }

    /**
     * Return the name of the option in the WP DB.
     *
     * @since 1.0.0
     * @return bool
     */
    public function is_enabled() {
        $is_enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'no';
        if ($is_enabled =='yes') {
            return true;
        }
        return false;
    }


    /**
     * Username Method
     * 
     * @return string
     * */
    public function get_username()
    {
        return $this->settings['username'];
    }


    /**
     * Shipping Method Key
     * 
     * @return string
     * */
    public function get_api_key()
    {
        return $this->settings['api_key'];
    }

    /**
     * Shipping Method Origin Zipcode
     * 
     * @return string
     * */
    private function get_origin_zipcode()
    {
        return $this->settings['origin_zipcode'];
    }

    /**
     * Request Auth Header
     * 
     * @return mixed
     * */
    public function get_auth_header()
    {
        $apiKey = $this->settings['api_key'] ?? null;
        $username = $this->settings['username'] ?? null;
        $password = $this->settings['password'] ?? null;
        return [
            'cache-control' => 'no-cache',
            'channel' => 'Woocommerce',
            'Content-Type' => 'application/json',
            'api_token' => $apiKey,
            'curl_token' => bin2hex(random_bytes(10)),
            'password' => $password,
            'username' => $username
          ];
    }

    /**
     * order Creation
     * 
     * @param array $payload
     * 
     * @return array
     */
    public function booking_creation($payload = [])
    {
        $endpoint = self::BOOKING_LIVE_CREATION_END_POINT;
        $headers = [
            'cache-control' => 'no-cache',
            'channel' => 'Woocommerce',
            'Content-Type' => 'application/json'
        ];

        $args = array(
            'headers' => $headers,
            'body'    => json_encode($payload)
        );
        try {
            $response = wp_remote_post($endpoint, $args);
            $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            $data = json_decode($response_body, true);
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"response" =>$data,'response_code' =>$response_code]);
            return $data;
        } catch (\Exception $e) {
            $response = ["status"=> false, "message" =>$e->getMessage()];
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"Exception" =>$response]);
            return $response;
        }
    }

    /**
     * This function insert new waybill record to waybill
     * 
     * @param int $orderid
     * @param string $waybill
     * @param string $shipping_charge
     * 
     * @return void
     */
    public function insert_record_to_waybill($orderid, $waybill, $shipping_charge = null)
    {
        global $wpdb;
        $tablename = $wpdb->prefix.'truxcargo_waybill';
        $wpdb->insert( $tablename, array(
                'waybill' => $waybill ?? "", 
                'order_id' => $orderid,
                'shipping_charge' => $shipping_charge
            )
        );
    }

    /**
     * This function update waybill record to waybill
     * 
     * @param int $orderid
     * @param string $waybill
     * @param string $shipping_charge
     * 
     * @return void
     */
    public function update_record_to_waybill($orderid, $waybill, $shipping_charge = null)
    {
        global $wpdb;
        $tablename = $wpdb->prefix.'truxcargo_waybill';
        $wpdb->update( $tablename, array(
                'waybill' => $waybill ?? "", 
                'shipping_charge' => $shipping_charge ?? "", 
            ), array(
                'order_id' => $orderid, 
            )
        );
    }

    /**
     * shipping Label Download
     * 
     * @param string $waybill
     * 
     * @return string
     * 
     * @throws \Exception
     */
    public function shipping_label_download($payload)
    {
        $endpoint = self::SHIPPING_LIVE_SHIPPING_LABEL_END_POINT;
        $headers = [
            'cache-control' => 'no-cache',
            'channel' => 'Woocommerce',
            'Content-Type' => 'application/json'
        ];
        $payload['key'] = $this->get_api_key();
        $args = array(
            'headers' => $headers,
            'body' => json_encode($payload)
        );
        try {
            $response = wp_remote_post($endpoint, $args);
            $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                throw new \Exception("Something went wrong: $error_message");
            }
            $response = json_decode($response_body, true);
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"response" =>$response,'response_code' =>$response_code]);
            $file_name = 'waybill-'.$payload['waybill'].'.png';
            header("Content-type: image/png");  
            header("Cache-Control: no-store, no-cache");  
            header('Content-Disposition: attachment; filename="'.$file_name.'"');
            $string_pieces = explode( ";base64,", $response['label']);
            echo base64_decode($string_pieces[1]);
        } catch (\Exception $e) {
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"Exception" =>$e->getMessage()]);
            throw new \Exception('Something went wrong. while saving AWB! '.$e->getMessage()); 
        }
    }

    /**
     * Request for download warehouse
     *
     * @return array
     * 
     * @throws \Exception
     */
    public function request_for_download_warehouse()
    {
        $endpoint = self::DOWNLOAD_WAREHOUSE_LIVE_END_POINT;
        $headers = $this->get_auth_header();
        $get_key = $this->get_api_key();
        $args = array(
            'headers' => $headers,
            'body'    => json_encode(['key' => $get_key])
        );
        try {
            $response = wp_remote_post($endpoint, $args);
            $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            $data = json_decode($response_body, true);
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"response" =>$data,'response_code' =>$response_code]);
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"Exception" =>$error_message]);
                throw new \Exception("Something went wrong: $error_message");
            }
            return $data;
        } catch (\Exception $e) {
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"Exception" =>$e->getMessage()]);
            throw new \Exception('Something went wrong. while downloading warehouse! '. $e->getMessage()); 
        }
    }

    /**
     * This function provide shipping charge according to current shipping address
     * @param array $obj
     * 
     * @return int|string|null
     */
    public function get_shippin_charge($obj)
    {
        $total_weight = 0;
        $total_length = [];
        $total_width = [];
        $total_height = [];
        $total_quantity = [];
        if (!isset($obj['destination']) || !$obj['destination'] || !isset($obj['destination']['postcode']) || !$obj['destination']['postcode']) return null;
        foreach ($obj['contents'] as $item) {
            $total_weight += (int)$item['data']->get_weight();
            $total_length[] = $item['data']->get_length();
            $total_width[] = $item['data']->get_width();
            $total_height[] = $item['data']->get_height();
            $total_quantity[] = $item['quantity'];
        }
        $total_quantity = $total_quantity ?? 1;
        $total_weight = $total_weight ? $total_weight : 1;
        $payload = [
            'key' => $this->get_api_key(),
            'origin' => $this->get_origin_zipcode(),
            'destination' => $obj['destination']['postcode'],
            'mode' => 'Prepaid',
            'cod_amount' => 0,
            'profit' => "",
            'weight' => $total_weight,
            'count' => $total_quantity,
            'length' => $total_length,
            'width' => $total_width,
            'height' => $total_height,
            'total_amount' => $obj['contents_cost'],
            'insurance' => 'No'
        ];

        $headers = [
            'cache-control' => 'no-cache',
            'channel' => 'Woocommerce',
            'Content-Type' => 'application/json'
          ];
        $args = array(
            'headers' => $headers,
            'body'    => json_encode($payload)
        );
        try {
            $response = wp_remote_post(self::SHIPPING_CHARGE_LIVE_END_POINT, $args);
            $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            $data = json_decode($response_body, true);
            $this->write_log(["endpoint" =>self::SHIPPING_CHARGE_LIVE_END_POINT,"payload" => $args,"response" =>$data,'response_code' =>$response_code]);
            if ($data['status']) {
                return $data['shipping_charge'];
            }
            return null;
        } catch (\Exception $e) {
            $this->write_log(["endpoint" =>self::SHIPPING_CHARGE_LIVE_END_POINT,"payload" => $args,'Exception' => $e->getMessage()]);
            return null;
        }

    }

    /**
     * Track carrier
     * 
     * @param array $payload
     * 
     * @return array
     * 
     * @throws \Exception
     */
    public function shipping_tracking($payload = [])
    {
        $endpoint = self::SHIPPING_LIVE_TRACKING_END_POINT;

        $headers = [
            'cache-control' => 'no-cache',
            'channel' => 'Woocommerce',
            'Content-Type' => 'application/json'
          ];
        $payload['key'] = $this->get_api_key();
        $args = array(
            'headers' => $headers,
            'body'    => json_encode($payload)
        );
        try {
            $response = wp_remote_post($endpoint, $args);
            $response_code = wp_remote_retrieve_response_code( $response );
            $response_body = wp_remote_retrieve_body( $response );
            $data = json_decode($response_body, true);
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                throw new \Exception("Something went wrong: $error_message");
            }
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,"response" =>$data,'response_code' =>$response_code]);
            return $data;
        } catch (\Exception $e) {
            $this->write_log(["endpoint" =>$endpoint,"payload" => $args,'Exception' => $e->getMessage()]);
            throw new \Exception('Something went wrong. while saving AWB!'); 
        }
    }

    /**
     * This function write log of every request 
     * if log enable from admin
     * 
     * @param string $log
     *
     * @return void
     */
    private function write_log($log) {
        if ($this->settings['is_log'] ==='yes') {
            $upload_dir = wp_upload_dir();
            $fileName = $upload_dir['basedir'].'/truxcargo.log';
            if (is_array($log) || is_object($log)) {
                file_put_contents($fileName, print_r($log, true).PHP_EOL , FILE_APPEND | LOCK_EX);
            } else {
                file_put_contents($fileName, $log.PHP_EOL , FILE_APPEND | LOCK_EX);
            }
        }
    }

}

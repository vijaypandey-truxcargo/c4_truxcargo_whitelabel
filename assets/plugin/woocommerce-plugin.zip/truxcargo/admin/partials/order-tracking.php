<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/admin/partials
 */

if($awb): ?>
    <?php 
        $pdf_url = wp_nonce_url( add_query_arg( array(
                        'action'        => 'generate_truxcargo_wcpdf',
                        'document_type' => 'pdf',
                        'waybill'     => $awb,
                    ), admin_url( 'admin-ajax.php' ) ), 'generate_truxcargo_wcpdf' );
    ?>
    <table class="track-truxcargo-table">
        <tr>
            <th>TruxCargo Shipping</th>
            <td><button type="button" class="track-truxcargo" url="<?= admin_url( 'admin-ajax.php' ); ?>" awb="<?= $awb; ?>">Track Courier</button></td>
        </tr>
        <tr>
            <th>AWB</th>
            <td><strong><?=$awb?></strong></td>
        </tr>
        <tr>
            <th>Print Shipment</th>
            <td><a target="_blank" href="<?= $pdf_url; ?>">Download</a></td>
        </tr>
    </table>
<?php else: ?>
    <?php 
        $checkAvlblity = wp_nonce_url( add_query_arg( array(
                        'action'        => 'check_availability_truxcargo',
                        'document_type' => 'json',
                        'order_id'     => $order_id,
                    ), admin_url( 'admin-ajax.php' ) ), 'check_availability_truxcargo' );
        $createUrl = wp_nonce_url( add_query_arg( array(
                    'action'        => 'create_order_truxcargo',
                    'document_type' => 'json',
                    'order_id'     => $order_id,
                ), admin_url( 'admin-ajax.php' ) ), 'create_order_truxcargo' );
        ?>
        <?php 
            $defaultWrs = null;
            $createOrderElmt = '<tr><th><select name="warehouse" id="warehouse-for-create-order">';
            foreach ($warehouses as $key => $warehouse):
                if($key==0)
                {
                    $defaultWrs = $warehouse->warehouse;
                }
                $createOrderElmt .= '<option value="'.$warehouse->warehouse.'">'.$warehouse->warehouse.'</option>';
            endforeach;
            $createOrderElmt .= '</select></th><td><button type="button" class="create-order-truxcargo" url="'.$createUrl.'&warehouse='.$defaultWrs.'" order_id="'.$order_id.'">Create Shipment</button></td></tr>';

        ?>
    <table class="track-truxcargo-table">
        <?php if($method_code == 'truxcargo'): ?>
            <?= $createOrderElmt; ?>
        <?php else: ?>
            <tr>
                <th>Check Availability with TruxCargo</th>
                <td>
                    <button type="button" class="check-order-truxcargo" url="<?=$checkAvlblity; ?>" order_id="<?=$order_id?>">Check Status</button>
                </td>
            </tr>
        <?php endif; ?>
    </table>
    <script>
        var createOrderElmt = `<?= $createOrderElmt; ?>`;
    </script>
<?php endif; ?>
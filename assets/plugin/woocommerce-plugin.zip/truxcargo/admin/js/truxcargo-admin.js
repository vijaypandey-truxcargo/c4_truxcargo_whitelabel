(function( $ ) {
	'use strict';

	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	 function createPopup(data){
	 	var htmlView = `<div id="track-truxcargo-modal-dialog">
			<div class="track-truxcargo-modal track-order-preview">
				<div class="wc-backbone-modal-content" tabindex="0">
					<section class="wc-backbone-modal-main" role="main">
						<header class="wc-backbone-modal-header">
							<h3>Tracking Information</h3>
							<button class="modal-close truxcargo-close-model modal-close-link dashicons dashicons-no-alt">
								<span class="screen-reader-text">Close modal panel</span>
							</button>
						</header>`;
							htmlView += `<article>
								<h4>Shipment #${data.orderId}</h4>
								<table>
									<tr>
										<th>Tracking Number</th>
										<td>${data.tracking_no}</td>
									</tr>
									
									<tr>
										<th>Info</th>
										<td>`;
											htmlView += `
											<h5><strong>History</strong></h5>
											<table>
											<tr>
												<th>Location</th>
												<th>Details</th>
												<th>Date</th>
												<th>Time</th>
											</tr>
											`;
											$.each(data.scaninfo, function (key, scan) {
												var datetime = new Date(scan.date);
												htmlView += `
												<tr>
													<td>${scan.location}</td>
													<td>${scan.remark}</td>
													<td>${datetime.getDate()}-${datetime.getMonth()+1}-${datetime.getFullYear()}</td>
													<td>${datetime.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })}</td>
												</tr>`;
											});
											htmlView += `</table>`;
										htmlView += `</td>
									</tr>

								</table>
							</article>`;
					htmlView += `</section>
				</div>
			</div>
		</div>`;
		$('body').append(htmlView);
	 }
	 $(document).on('click', '.truxcargo-close-model', function(event) {
	 	event.preventDefault();
	 	/* Act on the event */
	 	$("#track-truxcargo-modal-dialog").remove();
	 });

	 $(document).on('click', '.check-order-truxcargo', function(event) {
	 	event.preventDefault();
	 	/* Act on the event */
	 	var ajaxUrl = $(this).attr('url');
	 	var slectorElm = $(this);
	 	$(slectorElm).text('Please wait.....');
	 	$.ajax({ 
		     url: ajaxUrl, 
		     type: 'GET',
		     dataType: 'json',     
		     success: function(response) {
		     	if (response.status) {
		 			$(slectorElm).text('Check Status');
		 			$('.track-truxcargo-table > tbody').html(createOrderElmt)
		     	} else {
		     		alert(response.message);
		     	}
		    }
		});
	 });

	 $(document).on('click', '.download-warehouse', function(event) {
	 	event.preventDefault();
	 	/* Act on the event */
	 	var ajaxUrl = $(this).attr('href');
	 	var slectorElm = $(this);
	 	$(slectorElm).text('Please wait.....');
	 	$.ajax({ 
		     url: ajaxUrl, 
		     type: 'GET',
		     dataType: 'json',     
		     success: function(response) {
		     	if (response.status) {
		 			location.reload();
		     	} else {
		     		alert(response.message);
		     	}
		    }
		});
	 });
	 $(document).on('click', '.create-order-truxcargo', function(event) {
	 	event.preventDefault();
	 	/* Act on the event */
	 	var ajaxUrl = $(this).attr('url');
	 	var selector = $(this);
	 	var href = new URL(ajaxUrl);
	 	var warehouse = href.searchParams.get('warehouse');
		if (warehouse == undefined || warehouse == null || !warehouse) {
			alert('Please selector warehouse!');
			return;
		}
	 	$(selector).text('Please wait....');
	 	$.ajax({ 
		     url: ajaxUrl, 
		     type: 'GET',
		     dataType: 'json',     
		     success: function(response) {
			 	$(selector).text('Create Shipment');
		     	if (response && response.status) {
		     		location.reload();
		     	} else {
		     		var message = response.message ?? "Something went wrong!";
		     		alert(message)
		     	}
		    }
		});
	 });
	 $(document).on('change','#warehouse-for-create-order', function(event) {
	 	var slctWarehouse = $(this).val();
	 	var actionUrl = $('.create-order-truxcargo').attr('url');
	 	var href = new URL(actionUrl);
	 	href.searchParams.set('warehouse', slctWarehouse);
	 	$('.create-order-truxcargo').attr('url', href.toString());
	 });

	 $(document).on('click', '.track-truxcargo', function(event) {
	 	event.preventDefault();
	 	/* Act on the event */
	 	var slectorElm = $(this);
	 	$(slectorElm).text('Loading.....');
	 	var awbNumber = $(this).attr('awb');
	 	var ajaxUrl = $(this).attr('url');
	 	$.ajax({ 
		     data: {action: 'track_truxcargo_courier', awb:awbNumber},
		     type: 'post',
		     url: ajaxUrl,      
		     success: function(response) {
	 			$(slectorElm).text('Track Courier');
		     	if (response.status == true && response.data) {
		     		createPopup(response.data);
		     	}
		    }
		});
	 });

})( jQuery );

<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/admin
 * @author     Trux Cargo <truxcargo@gmail.com>
 */
class Truxcargo_Admin extends Truxcargo_Service {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
        parent::__construct($plugin_name, $version);

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Truxcargo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Truxcargo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/truxcargo-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Truxcargo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Truxcargo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/truxcargo-admin.js', array( 'jquery' ), $this->version, false );

	}
	/**
	 * Register Shipping Method.
	 *
	 * @since    1.0.0
	 */
	public function truxcargo_shipping_init()
	{
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/truxcargo-shipping.php';
	}

	/**
	 * Add Shipping Method.
	 *
	 * @since    1.0.0
	 */
	public function add_truxcargo_shipping_method( $methods )
	{
		$methods['truxcargo'] = 'TruxCargo_Shipping_Method';
        return $methods;
	}

    public function generate_truxcargo_wcpdf()
    {
        $waybill = $_GET['waybill'] ?? null;
        $this->shipping_label_download(['waybill' => $waybill]);
    }

	public function truxcargo_validate_order( $posted )   {
 
        $packages = WC()->shipping->get_packages();
 
        $chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
         
        if( is_array( $chosen_methods ) && in_array( 'truxcargo', $chosen_methods ) ) {
             
            foreach ( $packages as $i => $package ) {
 
                if ( $chosen_methods[ $i ] != "truxcargo" ) {
                             
                    continue;
                             
                }
 
                $TruxCargo_Shipping_Method = new TruxCargo_Shipping_Method();
                $weightLimit = 100000;
                $weight = 0;
 
                foreach ( $package['contents'] as $item_id => $values ) 
                { 
                    $_product = $values['data']; 
                    $weight = $weight; 
                    // $weight = $weight + $_product->get_weight() * $values['quantity']; 
                }
 
                $weight = wc_get_weight( $weight, 'kg' );
                
                if( $weight > $weightLimit ) {
 
                        $message = sprintf( __( 'Sorry, %d kg exceeds the maximum weight of %d kg for %s', 'truxcargo' ), $weight, $weightLimit, $TruxCargo_Shipping_Method->title );
                             
                        $messageType = "error";
 
                        if( ! wc_has_notice( $message, $messageType ) ) {
                         
                            wc_add_notice( $message, $messageType );
                      
                        }
                }
            }       
        } 
    }

    public function truxcargo_order_process($order_id, $old_status, $new_status)
    {
    	if ($new_status != 'processing') return;
    	$order = wc_get_order($order_id);
    	if (!$order->has_shipping_method('truxcargo')) return;
    	$payload = $this->get_booking_data_format($order);
        $booking_data = $this->booking_creation($payload);
        $this->insert_record_to_waybill($order_id,$booking_data['waybill']);
    }

    /**
     * getBookingDataFormat
     * @param mixed $order
     * @return mixed
     * */
    public function get_booking_data_format($order)
    {
        $response = [];
        $objectData = [];

        $objectData['key'] = $this->get_api_key();
        // order payment mode
        $paymentMode = in_array(get_post_meta($order->get_id(),'_payment_method',true),['cod','cheque'])?'COD':'Prepaid';
        $objectData['mode'] = $paymentMode;
        $objectData['cod_amount'] = $paymentMode=="COD"?$order->get_total():0;
        $objectData['profit'] = "";
        $productNames = [];
        $products = $order->get_items();
        $total_weight = 0;
        $totalItems = 0;
        $countItems = [];
        $lengthItems = [];
        $widthItems = [];
        $heightItems = [];
        foreach ($products as $pkey => $product) {
            $productNames[] = $product->get_name();
            $objprdct = $product->get_product();
            $item_weight = $objprdct->get_weight() ?? $this->get_default_weight();
            $total_weight += (int)$product->get_quantity() * floatval($item_weight);
            $totalItems += $product->get_quantity();
            $countItems[] = $product->get_quantity();
            $lengthItems[] = $objprdct->get_length();
            $widthItems[] = $objprdct->get_width();
            $heightItems[] = $objprdct->get_height();
        }
        $objectData['description'] = implode(',', $productNames);
        $objectData['weight'] = $this->get_total_weight_with_unit($total_weight);
        $objectData['order_id'] = $order->get_id();
        $objectData['tracking_id'] = $order->get_id();
        $objectData['qty'] = $totalItems;
        $objectData['count'] = $countItems;
        $objectData['length'] = $lengthItems;
        $objectData['width'] = $widthItems;
        $objectData['height'] = $heightItems;
        $objectData['ewbn'] = "";
        $objectData['total_amount'] = $order->get_total();
        $objectData['hsn_code'] = $order->get_id();
        $objectData['seller_name'] = $this->get_username();
        $objectData['seller_add'] = get_option('woocommerce_store_address', true);
        $objectData['seller_inv'] = $order->get_id();
        $objectData['insurance'] = 'No';
        $objectData['seller_tin'] = '';
        $objectData['email'] = $order->get_billing_email();
        $objectData['name'] = $order->get_shipping_first_name().' '.$order->get_shipping_last_name();
        $objectData['phone'] = $order->get_billing_phone();
        $objectData['pin'] = $order->get_shipping_postcode();
        $objectData['address'] = $order->get_shipping_address_1().', '.$order->get_shipping_address_2();
        $objectData['city'] = $order->get_shipping_city();
        $objectData['state'] = $order->get_shipping_state();

        return $objectData;
    }

    public function truxcargo_admin_menu()
    {
        add_submenu_page(
            'woocommerce',
            __( 'Warehouse', 'truxcargo' ),
            __( 'Warehouse', 'truxcargo' ),
            'manage_options',
            'truxcargo-warehouse',
            array( $this, 'add_truxcargo_warehouse_submenu' ),
            9999
        );
        add_submenu_page(
            'woocommerce',
            __( 'Waybill', 'truxcargo' ),
            __( 'Waybill', 'truxcargo' ),
            'manage_options',
            'truxcargo-waybill',
            array( $this, 'add_truxcargo_waybill_submenu' ),
            9999
        );
    }

    public function add_truxcargo_warehouse_submenu()
    {
        $waybill_table = new Warehouses_List_Table();
        $download_link = wp_nonce_url( add_query_arg( array(
            'action'        => 'download_my_warehouse',
            'document_type' => 'json',
        ), admin_url( 'admin-ajax.php' ) ), 'download_my_warehouse' );
        ?>
        <div class="wrap">
            <h2><?php esc_html_e( 'All Warehouse', 'truxcargo' ); ?></h2>
            <a href="<?= $download_link; ?>" class="page-title-action download-warehouse">Download Warehouse</a>
            <form id="all-drafts" method="get">
                <input type="hidden" name="page" value="truxcargo-warehouse" />

                <?php
                $waybill_table->prepare_items();
                $waybill_table->search_box( 'Search', 'search' );
                $waybill_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function add_truxcargo_waybill_submenu()
    {
        $waybill_table = new Waybill_List_Table();
        ?>
        <div class="wrap">
            <h2><?php esc_html_e( 'All Waybill List', 'admin-table-tut' ); ?></h2>
            <form id="all-drafts" method="get">
                <input type="hidden" name="page" value="truxcargo-waybill" />

                <?php
                $waybill_table->prepare_items();
                $waybill_table->search_box( 'Search', 'search' );
                $waybill_table->display();
                ?>
            </form>
        </div>
        <?php
    }

    public function truxcargo_warehouse_screen_settings()
    {
       $screen = get_current_screen();
        // get out of here if we are not on our settings page
        if(!is_object($screen) || $screen->id != 'woocommerce_page_truxcargo-warehouse')
            return;
     
        $args = array(
            'label' => __('Warehouse per page', 'truxcargo'),
            'default' => 10,
            'option' => 'truxcargo_per_page'
        );
        add_screen_option( 'per_page', $args );
    }

    public function truxcargo_waybill_screen_settings()
    {
       $screen = get_current_screen();
        // get out of here if we are not on our settings page
        if(!is_object($screen) || $screen->id != 'woocommerce_page_truxcargo-waybill')
            return;
     
        $args = array(
            'label' => __('Waybill per page', 'truxcargo'),
            'default' => 10,
            'option' => 'truxcargo_per_page'
        );
        add_screen_option( 'per_page', $args );
    }

    public function truxcargo_set_screen_option($status, $option, $value) {
        if ( 'truxcargo_per_page' == $option ) return $value;
    }

    public function check_availability_truxcargo()
    {
        $order_id = $_GET['order_id'] ?? null;
        $order = wc_get_order($order_id);
        $zipcode = $order->get_shipping_postcode();
        $isAvailable = $this->is_available_service($zipcode);
        $msg = 'Service Not Available on this postcode '.$zipcode;
        if ($isAvailable == true) {
            $msg = 'Service Available on this postcode '.$zipcode;
        }
        return wp_send_json(['status' => $isAvailable, 'message' => $msg]);
    }


    public function create_order_truxcargo()
    {
        $order_id = $_GET['order_id'] ?? null;
        $warehouse = $_GET['warehouse'] ?? null;
        $order = wc_get_order($order_id);
        $payload = $this->get_booking_data_format($order);
        $payload['warehouse'] = $warehouse;
        $booking_data = $this->booking_creation($payload);
        if ($booking_data['status'] == true) {
            $waybill = $booking_data['data']['waybill'] ?? null;
            $shipping_charge = $booking_data['data']['shipping_charge'] ?? null;
            $this->insert_record_to_waybill($order_id, $waybill, $shipping_charge);
        }
        return wp_send_json($booking_data);
    }

    public function download_my_warehouse()
    {
        global $wpdb;
        $tablename = $wpdb->prefix.'truxcargo_warehouses';
        $response = $this->request_for_download_warehouse();
        $rtresponse = ['status' => false, 'msg' => 'Something went wrong. please try again!'];
        if ($response['status']) {
            $wpdb->query('TRUNCATE '.$tablename);
            $warehouses = $response['data']['info'] ?? [];
            $instStatus = $this->insert_all_warehouses($warehouses);
            if ($instStatus) {
                $rtresponse['status'] = true;
                $rtresponse['msg'] = 'Warehouse downloaded successfully';
            }
            
        }
        return wp_send_json($rtresponse);
    }

    public function insert_all_warehouses($warehouses = [])
    {
        global $wpdb;
        $tablename = $wpdb->prefix.'truxcargo_warehouses';
        $wh_query = "INSERT INTO ".$tablename." (warehouse, name, phone, address, pincode, city, state) VALUES ";
        foreach ($warehouses as $warehouse) {
            $wh_query .= $wpdb->prepare(
                "(%s, %s, %s, %s, %s, %s, %s),",
                 $warehouse['warehouse'],$warehouse['name'],$warehouse['phone'],$warehouse['address'],$warehouse['pincode'],$warehouse['city'],$warehouse['state']
              );
        }
        $wh_query = rtrim( $wh_query, ',' ) . ';';
        if($wpdb->query( $wh_query )) {
          return true;
        } else {
          return false;
        }
    }

    public function order_tracking_detials()
    {
        global $post;
        global $wpdb;

        if (!$this->is_enabled()) return;

        $tablename = $wpdb->prefix.'truxcargo_waybill';
        $orderId = $post->ID;
        $method_code = $this->get_shipping_method_code($orderId);
        $result = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tablename WHERE order_id = %s", $orderId ) );
        $params = ['method_code'=>$method_code,'order_id'=>$orderId];
        if ($result && $result->order_id) {
            $params['awb'] = $result->waybill;
        }
        add_meta_box("truxcargo-order-tracking-meta-box", "Truxcargo Shipment", [$this,"tracking_order_context"], "shop_order", "advanced", "high", $params);
    }

    public function track_truxcargo_courier()
    {
        $awb = $_POST['awb'] ?? null;
        $payload = ["waybill" => $awb];
        $response = $this->shipping_tracking($payload);
        return wp_send_json($response);
    }

    public function get_shipping_method_code($orderId)
    {
        global $wpdb;
        $metaTable = $wpdb->prefix.'woocommerce_order_itemmeta';
        $mainTable = $wpdb->prefix.'woocommerce_order_items';
        $result = $wpdb->get_row( $wpdb->prepare( "select meta.meta_value from $metaTable as meta inner join $mainTable as main  on main.order_item_id = meta.order_item_id where main.order_id = %d and main.order_item_type='shipping' and meta.meta_key='method_id'", $orderId ) );
        if ($result && $result->meta_value) {
            return $result->meta_value;
        }
        return null;
    }

    public function get_warehouse_list()
    {
        global $wpdb;
        $nameTable = $wpdb->prefix.'truxcargo_warehouses';
        $result = $wpdb->get_results("select * from $nameTable" );
        return $result;
    }

    public function tracking_order_context($post, $params)
    {   
        $method_code = $params['args']['method_code'] ?? null;
        $order_id = $params['args']['order_id'] ?? null;
        $awb = $params['args']['awb'] ?? null;
        $warehouses = $this->get_warehouse_list();
        require_once plugin_dir_path( __FILE__ ).'partials/order-tracking.php';
    }

}

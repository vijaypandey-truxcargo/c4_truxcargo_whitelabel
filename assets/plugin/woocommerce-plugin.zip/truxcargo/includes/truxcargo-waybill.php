<?php

if(!class_exists('WP_List_Table')){
	require_once(ABSPATH.'wp-admin/includes/class-wp-list-table.php' );
}

class Waybill_List_Table extends \WP_List_Table {

	/**
	 * Const to declare number of posts to show per page in the table.
	 */
	const POSTS_PER_PAGE = 10;


	/**
	 * Draft_List_Table constructor.
	 */
	public function __construct() {

		parent::__construct(
			array(
				'singular' => 'Waybill',
				'plural'   => 'Waybills',
				'ajax'     => false,
			)
		);
	}

	private function get_per_page_waybill()
	{
		// get the current user ID
		$user = get_current_user_id();
		// get the current admin screen
		$screen = get_current_screen();
		// retrieve the "per_page" option
		$screen_option = $screen->get_option('per_page', 'option');
		// retrieve the value of the option stored for the current user
		$per_page = get_user_meta($user, $screen_option, true);
		if ( empty ( $per_page) || $per_page < 1 ) {
			// get the default value if none is set
			$per_page = $screen->get_option( 'per_page', 'default' );
		}
		return $per_page;
	}
	private function get_total_waybill_page()
	{
		// WP Globals
        global $table_prefix, $wpdb;
        // Waybill Table
        $waybill_table = $table_prefix . 'truxcargo_waybill';
        $searchKey = $_GET['s'] ?? null;
        if ($searchKey && !empty($searchKey)) {
			$total_waybill = $wpdb->get_var('SELECT COUNT(*) FROM '.$waybill_table.' WHERE `waybill` LIKE "%'.$searchKey.'%" or `order_id` LIKE "%'.$searchKey.'%" or `shipping_charge` LIKE "%'.$searchKey.'%"');
        } else {
			$total_waybill = $wpdb->get_var('SELECT COUNT(*) FROM '.$waybill_table);
        }
		$per_page = $this->get_per_page_waybill();
		if ($total_waybill > $per_page) {
			$number_of_pages = $total_waybill / $per_page;
			return ceil($number_of_pages);
		}
		return 1;
	}
	/**
	 * Return instances Waybill object.
	 *
	 * @return WP_Query Custom query object with passed arguments.
	 */
	protected function get_waybill_object() {
		// WP Globals
        global $table_prefix, $wpdb;

        $per_page = $this->get_per_page_waybill();
        $paged = filter_input( INPUT_GET, 'paged', FILTER_VALIDATE_INT );

        // ORDER BY
        $orderby = sanitize_sql_orderby( filter_input( INPUT_GET, 'orderby' ) );
        // Order
		$order   = esc_sql( filter_input( INPUT_GET, 'order' ) );
		// search keyword
		$searchKey = esc_sql( filter_input( INPUT_GET, 's' ) );
		if ( empty( $orderby ) || 'view' == $orderby ) {
			$orderby = 'waybill';
		}

		if ( empty( $order ) || 'view' == $order ) {
			$order = 'DESC';
		}
		$offset = ((int)$paged - 1) * (int)$per_page;
		if ($paged == 0 || $paged == 1) {
			$offset = 0;
		}
        // Waybill Table
        $waybillTable = $table_prefix . 'truxcargo_waybill';
        if ($searchKey && !empty($searchKey)) {
			return $wpdb->get_results("SELECT * FROM ".$waybillTable.' WHERE `waybill` LIKE "%'.$searchKey.'%" or `order_id` LIKE "%'.$searchKey.'%" or `shipping_charge` LIKE "%'.$searchKey.'%"'.' ORDER BY '.$orderby.' '.$order.' '.' LIMIT '.$per_page.'  OFFSET '.$offset);
        }
		return $wpdb->get_results("SELECT * FROM ".$waybillTable.' ORDER BY '.$orderby.' '.$order.' '.' LIMIT '.$per_page.'  OFFSET '.$offset);
	}

	/**
	 * Display text for when there are no items.
	 */
	public function no_items() {
		esc_html_e( 'No Waybill found.', 'truxcargo' );
	}

	/**
	 * The Default columns
	 *
	 * @param  array  $item        The Item being displayed.
	 * @param  string $column_name The column we're currently in.
	 * @return string              The Content to display
	 */
	public function column_default( $item, $column_name ) {
		$pdf_url = wp_nonce_url( add_query_arg( array(
					'action'        => 'generate_truxcargo_wcpdf',
					'document_type' => 'pdf',
					'waybill'     => $item->waybill,
				), admin_url( 'admin-ajax.php' ) ), 'generate_truxcargo_wcpdf' );

		$regenerate_url = wp_nonce_url( add_query_arg( array(
					'action'        => 'regenerate_truxcargo_waybill',
					'document_type' => 'json',
					'order_id'     => $item->order_id,
				), admin_url( 'admin-ajax.php' ) ), 'regenerate_truxcargo_waybill' );
		$result = '';
		switch ( $column_name ) {
			case 'waybill':
				$result = $item->waybill;
				break;
			case 'order_id':
				$result = $item->order_id;
				break;
			case 'shipping_charge':
				$result = $item->shipping_charge;
				break;
			case 'view':
				$result = $item->waybill ? '<a target="_blank" href="'.$pdf_url.'">Print Shipment</a>': '<a target="_blank" href="'.$regenerate_url.'" class="regenerate_waybill_ajax" title="Please reload page after click on this link for view result">Regenerate Waybill</a>';
				break;
		}

		return $result;
	}

	/**
	 * Get list columns.
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'waybill'  => __( 'Waybill', 'truxcargo' ),
			'order_id'  => __( 'Order Id', 'truxcargo' ),
			'shipping_charge'  => __( 'Shipping Charge', 'truxcargo' ),
			'view'  => __( 'Action', 'truxcargo' ),
		);
	}


	/**
	 * Prepare the data for the WP List Table
	 *
	 * @return void
	 */
	public function prepare_items() {
		$columns               = $this->get_columns();
		$sortable              = $this->get_sortable_columns();
		$hidden                = array();
		$primary               = 'title';
		$this->_column_headers = array( $columns, $hidden, $sortable, $primary );
		$data                  = array();


		$get_waybill_obj = $this->get_waybill_object();



		$this->items = $get_waybill_obj;

		$this->set_pagination_args(
			array(
				'total_items' => count($get_waybill_obj),
				'per_page'    => $this->get_per_page_waybill(),
				'total_pages'    => $this->get_total_waybill_page(),
			)
		);
	}

	/**
	 * Get bulk actions.
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		return array();
	}


	/**
	 * Generates the table navigation above or below the table
	 *
	 * @param string $which Position of the navigation, either top or bottom.
	 *
	 * @return void
	 */
	protected function display_tablenav( $which ) {
		?>
	<div class="tablenav <?php echo esc_attr( $which ); ?>">

		<?php if ( $this->has_items() ) : ?>
		<div class="alignleft actions bulkactions">
			<?php $this->bulk_actions( $which ); ?>
		</div>
			<?php
		endif;
		$this->pagination( $which );
		?>

		<br class="clear" />
	</div>
		<?php
	}


	/**
	 * Include the columns which can be sortable.
	 *
	 * @return Array $sortable_columns Return array of sortable columns.
	 */
	public function get_sortable_columns() {

		return array(
			'waybill'  => array( 'waybill', false ),
			'order_id'   => array( 'order_id', false ),
			'shipping_charge'   => array( 'shipping_charge', false ),
		);
	}
}

<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 * @author     Trux Cargo <truxcargo@gmail.com>
 */
class Truxcargo {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Truxcargo_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'TRUXCARGO_VERSION' ) ) {
			$this->version = TRUXCARGO_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'truxcargo';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Truxcargo_Loader. Orchestrates the hooks of the plugin.
	 * - Truxcargo_i18n. Defines internationalization functionality.
	 * - Truxcargo_Admin. Defines all hooks for the admin area.
	 * - Truxcargo_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-truxcargo-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-truxcargo-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-truxcargo-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-truxcargo-public.php';

		// load table class
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/truxcargo-warehouses.php';

		// load table class
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/truxcargo-waybill.php';

		$this->loader = new Truxcargo_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Truxcargo_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Truxcargo_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Truxcargo_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'woocommerce_shipping_init', $plugin_admin, 'truxcargo_shipping_init' );
		$this->loader->add_filter( 'woocommerce_shipping_methods', $plugin_admin, 'add_truxcargo_shipping_method' );
		$this->loader->add_action( 'woocommerce_review_order_before_cart_contents', $plugin_admin, 'truxcargo_validate_order' , 10 );
        $this->loader->add_action( 'woocommerce_after_checkout_validation', $plugin_admin, 'truxcargo_validate_order' , 10 );
        $this->loader->add_action( 'woocommerce_order_status_changed', $plugin_admin, 'truxcargo_order_process' , 10, 3 );
        $this->loader->add_action('admin_menu',$plugin_admin, 'truxcargo_admin_menu');
        $this->loader->add_action('load-woocommerce_page_truxcargo-warehouse',$plugin_admin, 'truxcargo_warehouse_screen_settings',10, 10);
        $this->loader->add_action('load-woocommerce_page_truxcargo-waybill',$plugin_admin, 'truxcargo_waybill_screen_settings',10, 10);
        $this->loader->add_action('set-screen-option',$plugin_admin, 'truxcargo_set_screen_option',10, 3);
        $this->loader->add_action('wp_ajax_check_availability_truxcargo',$plugin_admin, 'check_availability_truxcargo');
        $this->loader->add_action('wp_ajax_nopriv_check_availability_truxcargo',$plugin_admin, 'check_availability_truxcargo');
        $this->loader->add_action('wp_ajax_download_my_warehouse',$plugin_admin, 'download_my_warehouse');
        $this->loader->add_action('wp_ajax_nopriv_download_my_warehouse',$plugin_admin, 'download_my_warehouse');
        $this->loader->add_action('add_meta_boxes',$plugin_admin, 'order_tracking_detials');
        // track courier
        $this->loader->add_action('wp_ajax_track_truxcargo_courier',$plugin_admin, 'track_truxcargo_courier');
        $this->loader->add_action('wp_ajax_nopriv_track_truxcargo_courier',$plugin_admin, 'track_truxcargo_courier');
        // Create Order Truxcargo
        $this->loader->add_action('wp_ajax_create_order_truxcargo',$plugin_admin, 'create_order_truxcargo');
        $this->loader->add_action('wp_ajax_nopriv_create_order_truxcargo',$plugin_admin, 'create_order_truxcargo');
        // pdf download
        $this->loader->add_action('wp_ajax_generate_truxcargo_wcpdf',$plugin_admin, 'generate_truxcargo_wcpdf');
        $this->loader->add_action('wp_ajax_nopriv_generate_truxcargo_wcpdf',$plugin_admin, 'generate_truxcargo_wcpdf');

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Truxcargo_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		$this->loader->add_action( 'woocommerce_shipping_truxcargo_is_available', $plugin_public, 'availability_shipping_truxcargo', 2, 10);
		$this->loader->add_action( 'woocommerce_order_details_after_order_table', $plugin_public, 'order_tracking_detials', 2, 10);

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Truxcargo_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}

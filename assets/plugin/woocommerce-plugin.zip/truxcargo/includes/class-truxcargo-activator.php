<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 * @author     Trux Cargo <truxcargo@gmail.com>
 */
class Truxcargo_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
        self::create_waybill_table();
        self::create_warehouses_table();
	}

    private static function create_waybill_table()
    {
        // WP Globals
        global $table_prefix, $wpdb;

        // Waybill Table
        $waybillTable = $table_prefix . 'truxcargo_waybill';
        // Create Waybill Table if not exist
        if( $wpdb->get_var( "show tables like '$waybillTable'" ) != $waybillTable ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$waybillTable` (";
            $sql .= " `id` int(11) unsigned NOT NULL AUTO_INCREMENT, ";
            $sql .= " `waybill` varchar(100) NOT NULL, ";
            $sql .= " `order_id` varchar(100) NOT NULL, ";
            $sql .= " `shipping_charge` varchar(100) NOT NULL, ";
            $sql .= "PRIMARY KEY (`id`) );";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta($sql);
        }
    }

    private static function create_warehouses_table()
    {
        // WP Globals
        global $table_prefix, $wpdb;

        // Waybill Table
        $waybillTable = $table_prefix . 'truxcargo_warehouses';
        // Create Waybill Table if not exist
        if( $wpdb->get_var( "show tables like '$waybillTable'" ) != $waybillTable ) {

            // Query - Create Table
            $sql = "CREATE TABLE `$waybillTable` (";
            $sql .= " `id` int(11) unsigned NOT NULL AUTO_INCREMENT, ";
            $sql .= " `warehouse` varchar(100) NOT NULL, ";
            $sql .= " `name` varchar(100) NOT NULL, ";
            $sql .= " `phone` varchar(15) NOT NULL, ";
            $sql .= " `address` varchar(255) NOT NULL, ";
            $sql .= " `pincode` varchar(10) NOT NULL, ";
            $sql .= " `city` varchar(100) NOT NULL, ";
            $sql .= " `state` varchar(100) NOT NULL, ";
            $sql .= "PRIMARY KEY (`id`) );";

            // Include Upgrade Script
            require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
        
            // Create Table
            dbDelta($sql);
        }
    }
}

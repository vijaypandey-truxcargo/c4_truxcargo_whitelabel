<?php
/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Truxcargo
 * @subpackage Truxcargo/includes
 * @author     Trux Cargo <truxcargo@gmail.com>
 */
class TruxCargo_Shipping_Method extends WC_Shipping_Method {
    private $plugin_version = '1.0.0';
    private $plugin_name = 'truxcargo';
    /**
     * Constructor for your shipping class
     *
     * @access public
     * @return void
     */
    public function __construct() {
        $this->id                 = 'truxcargo'; 
        $this->method_title       = __( 'TruxCargo Shipping', 'truxcargo' );  
        $this->method_description = __( 'TruxCargo For Shipping Method', 'truxcargo' ); 

        // Availability & Countries

        $this->init();

        $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';
        $this->title = isset( $this->settings['title'] ) ? $this->settings['title'] : __( 'TruxCargo Shipping', 'truxcargo' );
    }

    /**
     * Init your settings
     *
     * @access public
     * @return void
     */
    function init() {
        // Load the settings API
        $this->init_form_fields(); 
        $this->init_settings(); 

        // Save settings in admin if you have any defined
        add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
    }

    /**
     * Define settings field for this shipping
     * @return void 
     */
    function init_form_fields() { 

        $this->form_fields = array(

            'enabled'         => array(
                'title'       => __( 'Enable', 'truxcargo' ),
                'type'        => 'checkbox',
                'description' => __( 'Enable this shipping.', 'truxcargo' ),
                'default'     => 'yes'
             ),
            'is_log'         => array(
                'title'       => __( 'Log', 'truxcargo' ),
                'type'        => 'checkbox',
                'description' => __( 'Enable Log All Request/Response.', 'truxcargo' ),
                'default'     => 'no'
             ),
	         'username'      => array(
	            'title'       => __( 'Username', 'truxcargo' ),
	            'type'        => 'text',
	            'description' => __( 'Username', 'truxcargo' ),
				'desc_tip'    => false,
	        ),
	        'password'       => array(
	            'title'       => __( 'Password', 'truxcargo' ),
	            'type'        => 'text',
	            'description' => __( 'Password', 'truxcargo' ),
				'desc_tip'    => false,
	        ),
            'api_key'         => array(
                'title'       => __( 'Api Key', 'truxcargo' ),
                'type'        => 'text',
                'description' => __( 'Api Key', 'truxcargo' ),
                'desc_tip'    => false,
            ),
            'origin_zipcode'         => array(
                'title'       => __( 'Origin Zip Code', 'truxcargo' ),
                'type'        => 'text',
                'description' => __( 'Origin Zip Code', 'truxcargo' ),
                'desc_tip'    => false,
            ),
	        'title'           => array(
	            'title'       => __( 'Method Name/Title', 'truxcargo' ),
	            'type'        => 'text',
	            'description' => __( 'Title to be display on site', 'truxcargo' ),
	            'default'     => __( 'TruxCargo Shipping', 'truxcargo' ),
				'desc_tip'    => false,
	        )
         );

    }

    /**
     * This function is used to calculate the shipping cost. Within this function we can check for weights, dimensions and other parameters.
     *
     * @access public
     * @param mixed $package
     * @return void
     */
    public function calculate_shipping( $package = array() ) {
        $objService  = new Truxcargo_Service($this->plugin_name,$this->plugin_version);
        $coast = $objService->get_shippin_charge($package);
        if ($coast) {
            $rate = array(
                'id' => $this->id,
                'label' => $this->title,
                'cost' => $coast
            );
            $this->add_rate( $rate );
        }
        
    }
}

<?php

require '../includes/class-truxcargo-service.php';
/**
 * 
 */
class PrintWayBillShipment
{
	
	public function print()
	{
		echo "test here";
	}
}

$ClassObj = new PrintWayBillShipment();
$ClassObj->print();
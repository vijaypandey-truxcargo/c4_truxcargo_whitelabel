<?php if($awb): ?>
	<section class="woocommerce-tracking-details">
		<h2 class="woocommerce-column__title">Track your order</h2>
		<table>
			<tr>
				<td>TruxCargo Shipping</td>
				<td><button type="button" class="track-truxcargo" url="<?= admin_url( 'admin-ajax.php' ); ?>" awb="<?= $awb; ?>">Track Courier</button></td>
			</tr>
		</table>
	</section>
<?php endif; ?>

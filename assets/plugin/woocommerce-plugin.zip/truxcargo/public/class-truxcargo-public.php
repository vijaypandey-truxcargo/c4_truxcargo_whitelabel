<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://https://www.truxcargo.com/
 * @since      1.0.0
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Truxcargo
 * @subpackage Truxcargo/public
 * @author     Trux Cargo <truxcargo@gmail.com>
 */
class Truxcargo_Public extends Truxcargo_Service {
	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		parent::__construct($plugin_name, $version);

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Truxcargo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Truxcargo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/truxcargo-public.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Truxcargo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Truxcargo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/truxcargo-public.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 *  check availability of truxcargo
	 *
	 * @since    1.0.0
	 */
	public function availability_shipping_truxcargo($is_available, $package)
	{
		if (!$this->is_enabled())  return false;

		$postal_code = $package[ 'destination' ]['postcode'] ?? null;
		if (!$postal_code) return false;
		$is_available = $this->is_available_service($postal_code);
		if (!$is_available) return false;
		return true;
	}

	/**
	 *  Order tracking of truxcargo
	 *
	 * @since    1.0.0
	 */
	public function order_tracking_detials($order)
	{
        global $wpdb;
		$orderId = $order->get_id();
		$tablename = $wpdb->prefix.'truxcargo_waybill';
		$result = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $tablename WHERE order_id = %s", $orderId ) );
		$awb = "";
		if ($result && $result->waybill) {
			$awb = $result->waybill; 
		}
		require_once plugin_dir_path( __FILE__ ).'partials/order-tracking.php';
	}


}
